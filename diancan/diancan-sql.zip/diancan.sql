/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.5.53 : Database - diancan
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`diancan` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `diancan`;

/*Table structure for table `dinnertable` */

DROP TABLE IF EXISTS `dinnertable`;

CREATE TABLE `dinnertable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(20) NOT NULL COMMENT '餐桌名',
  `table_status` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '餐桌状态 0：空闲 1：预定',
  `orderDate` datetime DEFAULT NULL COMMENT '预定时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COMMENT='餐桌表';

/*Data for the table `dinnertable` */

insert  into `dinnertable`(`id`,`table_name`,`table_status`,`orderDate`) values (47,'餐桌19',0,NULL),(46,'餐桌18',0,NULL),(45,'餐桌17',0,NULL),(44,'餐桌16',0,NULL),(43,'餐桌15',0,NULL),(42,'餐桌14',0,NULL),(41,'餐桌13',0,NULL),(40,'餐桌12',0,NULL),(39,'餐桌11',0,NULL),(36,'餐桌8',0,NULL),(35,'餐桌7',0,NULL),(33,'餐桌5',0,NULL),(32,'餐桌4',0,NULL),(30,'餐桌2',0,NULL),(31,'餐桌3',0,NULL),(29,'餐桌1',0,NULL),(49,'餐桌21',0,NULL),(34,'餐桌6',0,NULL),(48,'餐桌20',0,NULL),(37,'餐桌9',0,NULL),(38,'餐桌10',0,NULL);

/*Table structure for table `food` */

DROP TABLE IF EXISTS `food`;

CREATE TABLE `food` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `food_name` varchar(20) NOT NULL COMMENT '食物名称',
  `type_id` int(11) NOT NULL COMMENT '食物分类ID',
  `price` double NOT NULL COMMENT '价格',
  `mp_price` double DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

/*Data for the table `food` */

insert  into `food`(`id`,`food_name`,`type_id`,`price`,`mp_price`,`remark`,`img`) values (20,'农家小炒肉',1,23,12,'乍一看跟回锅肉有点像，它属于湘菜或川菜，是以五花肉为主料，蒜、豆豉、线椒等为辅料炒制而成。焦香嫩滑的五花肉搭配上劲辣十足的线椒，组成了这道脍炙人口的经典湘菜。做好这个菜，食材第一，火候第二，突出到酸辣、香鲜、软嫩的品味，是最能见湘菜水平的家常菜。成品菜具有爆香味辣、肉质细嫩、滑嫩适口的特点','1560303009045.jpg'),(21,'蒜苗回锅肉',1,32,30,'蒜苗回锅肉的做法','1560303064639.jpg'),(22,'红烧肘子',3,31,19,'红烧肘子','1560303178254.jpg'),(23,'宫保鸡丁',2,19,12,'宫保鸡丁，是一道闻名中外的汉族传统名菜。鲁菜、川菜、贵州菜中都有收录，原料、做法有差别。该菜式','1560303255549.jpg'),(24,'赛螃蟹',9,35,30,'赛螃蟹是一道传统特色名菜，此菜口感滑嫩，营养丰富。主要是以鸡蛋为主料，经过烹饪之后，蛋清雪白似蟹肉，蛋黄金黄如蟹黄，不是螃蟹，胜似蟹味，所以，被称之为“赛螃蟹”。\r\n这道菜看似高大上，其实做法非常简单，就是把鸡蛋的蛋清和蛋黄分开炒过之后，再倒入事先兑好的姜汁就算完成了。不过，值得注意的是，调汁的时候最好是用白醋，这样炒出来鸡蛋会更漂亮。\r\n这道菜可以说是色香味俱全，鸡蛋这样做，完全颠覆了对它的认识，对于百姓来说，既经济又实惠，还饱了口福','1560303384186.jpg'),(25,'四喜丸子',1,16,14,'平日里家庭聚餐、同事聚会，怎么能少得了四喜丸子呢？四喜丸子是鲁菜的经典名菜之一，由四个色、香、味俱佳的肉丸组成，寓意人生福、禄、寿、喜四大喜事。常用于寿宴、家宴等宴席中的压轴菜，象征着富贵团圆，吉祥如意','1560303566455.jpg'),(26,'四喜丸子-副本',13,16,14,'平日里家庭聚餐、同事聚会，怎么能少得了四喜丸子呢？四喜丸子是鲁菜的经典名菜之一，由四个色、香、味俱佳的肉丸组成，寓意人生福、禄、寿、喜四大喜事。常用于寿宴、家宴等宴席中的压轴菜，象征着富贵团圆，吉祥如意','1560303566455.jpg');

/*Table structure for table `food_type` */

DROP TABLE IF EXISTS `food_type`;

CREATE TABLE `food_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(20) NOT NULL COMMENT '食物分类名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `food_type` */

insert  into `food_type`(`id`,`type_name`) values (13,'川菜'),(2,'粤菜'),(3,'鲁菜'),(4,'湘菜'),(9,'徽菜'),(10,'浙菜'),(11,'闽菜');

/*Table structure for table `orderdetail` */

DROP TABLE IF EXISTS `orderdetail`;

CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) DEFAULT NULL,
  `food_id` int(11) DEFAULT NULL,
  `foodCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

/*Data for the table `orderdetail` */

insert  into `orderdetail`(`id`,`orderId`,`food_id`,`foodCount`) values (22,9,20,1),(21,8,20,1),(20,7,25,6),(19,7,24,4),(18,7,23,2),(23,9,25,1),(24,9,22,1);

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) DEFAULT NULL,
  `orderDate` datetime DEFAULT NULL,
  `totalPrice` double DEFAULT NULL,
  `orderStatus` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `orders` */

insert  into `orders`(`id`,`table_id`,`orderDate`,`totalPrice`,`orderStatus`) values (8,35,'2019-06-12 06:37:19',23,0),(7,33,'2019-06-12 06:36:46',290,0),(9,45,'2019-06-12 06:37:32',39,1),(10,46,'2019-06-12 06:40:32',70,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
